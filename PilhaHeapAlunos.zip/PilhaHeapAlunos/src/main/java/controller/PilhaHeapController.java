package controller;

import model.Aluno;
import java.util.PriorityQueue;
import javax.swing.JOptionPane;

public class PilhaHeapController {
    private PriorityQueue<Aluno> pilhaHeap = new PriorityQueue<>((a1, a2) -> Double.compare(a2.getMedia(), a1.getMedia()));
    private double mediaTotal = 0.0;

    // Método para adicionar um aluno à pilha
    public void adicionarAluno() {
        // Solicita o nome do aluno
        String nome = "Ado - Rodrigo Silva dos Anjos"; // Nome fixo

        // Solicita as notas do aluno
        double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a Nota 1:"));
        double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Digite a Nota 2:"));

        // Cria um objeto Aluno com o nome e as notas fornecidas
        Aluno aluno = new Aluno(nome, nota1, nota2);

        // Adiciona o aluno à pilha
        pilhaHeap.offer(aluno);

        // Atualiza a média total com a nova média do aluno
        mediaTotal = (mediaTotal * (pilhaHeap.size() - 1) + aluno.getMedia()) / pilhaHeap.size();

        // Exibe uma mensagem de confirmação
        JOptionPane.showMessageDialog(null, "Aluno adicionado com sucesso!");
    }

    // Método para remover o aluno com a maior média da pilha
    public void removerAluno() {
        if (pilhaHeap.isEmpty()) {
            // Se a pilha estiver vazia, exibe uma mensagem de aviso
            JOptionPane.showMessageDialog(null, "A pilha de alunos está vazia.");
        } else {
            // Remove o aluno com a maior média da pilha
            Aluno alunoRemovido = pilhaHeap.poll();

            // Atualiza a média total após a remoção
            mediaTotal = (mediaTotal * (pilhaHeap.size() + 1) - alunoRemovido.getMedia()) / pilhaHeap.size();

            // Exibe uma mensagem informando qual aluno foi removido
            JOptionPane.showMessageDialog(null, "Aluno removido: " + alunoRemovido.getNome());
        }
    }

    // Método para mostrar a lista de alunos na pilha, incluindo suas informações
    public void mostrarPilha() {
        if (pilhaHeap.isEmpty()) {
            // Se a pilha estiver vazia, exibe uma mensagem de aviso
            JOptionPane.showMessageDialog(null, "A pilha de alunos está vazia.");
        } else {
            // Constrói uma mensagem com as informações dos alunos na pilha
            StringBuilder mensagem = new StringBuilder("=== Pilha de Alunos ===\n");
            for (Aluno aluno : pilhaHeap) {
                mensagem.append("Nome: ").append(aluno.getNome()).append("\n");
                mensagem.append("Nota 1: ").append(aluno.getNota1()).append("\n");
                mensagem.append("Nota 2: ").append(aluno.getNota2()).append("\n");
                mensagem.append("Média: ").append(aluno.getMedia()).append("\n");
                mensagem.append("=======================\n");
            }
            mensagem.append("Média Total: ").append(mediaTotal);

            // Exibe a mensagem com as informações da pilha
            JOptionPane.showMessageDialog(null, mensagem.toString());
        }
    }

    public static void main(String[] args) {
        PilhaHeapController controller = new PilhaHeapController();

        while (true) {
            // Apresenta um menu interativo usando JOptionPane
            String[] options = { "Adicionar aluno", "Remover aluno", "Mostrar pilha de alunos", "Sair" };
            int escolha = JOptionPane.showOptionDialog(null, "Escolha uma opção:", "Menu", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            // Executa a ação com base na escolha do usuário
            switch (escolha) {
                case 0:
                    controller.adicionarAluno();
                    break;
                case 1:
                    controller.removerAluno();
                    break;
                case 2:
                    controller.mostrarPilha();
                    break;
                case 3:
                    // Encerra o programa
                    JOptionPane.showMessageDialog(null, "Encerrando o programa.");
                    System.exit(0);
                    break;
                default:
                    // Exibe uma mensagem de erro se a escolha for inválida
                    JOptionPane.showMessageDialog(null, "Opção inválida. Tente novamente.");
            }
        }
    }
}
